var models = [
    {
        Key: "gpt-4o",
        Text: "gpt-4o",
    },
    {
        Key: "gpt-4-turbo",
        Text: "gpt-4-turbo",
    },
    {
        Key: "gpt-4",
        Text: "gpt-4",
    },
    {
        Key: "gpt-3.5-turbo",
        Text: "gpt-3.5-turbo",
    },
];
